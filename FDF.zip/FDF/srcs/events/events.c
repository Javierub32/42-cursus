/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   events.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jurbanej <jurbanej@student.42malaga.c      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/06 11:31:50 by jurbanej          #+#    #+#             */
/*   Updated: 2025/08/06 11:31:51 by jurbanej         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/fdf.h"

void	redraw_image(t_vars *vars)
{
	// Limpiar imagen anterior
	mlx_destroy_image(vars->mlx, vars->img);
	if (vars->projections)
		free(vars->projections);
	// Crear nueva imagen
	vars->img = mlx_new_image(vars->mlx, vars->width, vars->height);
	vars->addr = mlx_get_data_addr(vars->img, &vars->bits_per_pixel,
									&vars->line_length, &vars->endian);

	// Recrear proyecciones y dibujar
	create_projections(vars, vars->map);
	draw_wireframe(vars, vars->map);

	// Mostrar nueva imagen
	mlx_put_image_to_window(vars->mlx, vars->win, vars->img, 0, 0);
}

int	close_window(t_vars *vars)
{
	if (vars->projections)
		free(vars->projections);
	if (vars->map)
		clear_map(vars->map);
	if (vars->img)
		mlx_destroy_image(vars->mlx, vars->img);
	mlx_destroy_window(vars->mlx, vars->win);
	exit(0);
}

int	key_hook(int keycode, t_vars *vars)
{
	if (keycode == 65307)
	{
		close_window(vars);
		return (0);
	}

	if (keycode == 119 || keycode == 65362)
		vars->offset_y -= 100;
	else if (keycode == 115 || keycode == 65364)
		vars->offset_y += 100;
	else if (keycode == 97 || keycode == 65361)
		vars->offset_x -= 100;
	else if (keycode == 100 || keycode == 65363)
		vars->offset_x += 100;
	else if (keycode == 114)
		vars->angle_x += 0.1;
	else if (keycode == 116)
		vars->angle_x -= 0.1;
	else if (keycode == 102)
		vars->angle_y += 0.1;
	else if (keycode == 103)
		vars->angle_y -= 0.1;
	redraw_image(vars);
	return (0);
}

int	mouse_hook(int button, int x, int y, t_vars *vars)
{
	(void)x;
	(void)y;
	if (button == 4)
	{
		vars->scale *= 1.1;
		redraw_image(vars);
	}
	else if (button == 5)
	{
		vars->scale *= 0.9;
		if (vars->scale < 1)
			vars->scale = 1;
		redraw_image(vars);
	}
	return (0);
}


