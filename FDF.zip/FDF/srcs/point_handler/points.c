/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   points.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jurbanej <jurbanej@student.42malaga.c      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/06 11:32:42 by jurbanej          #+#    #+#             */
/*   Updated: 2025/08/06 11:32:42 by jurbanej         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/fdf.h"

static int	get_color(int height);

void	create_projections(t_vars *window, t_map *map)
{
	t_projection	*projections;
	t_point			*pts;
	int				i;

	pts = create_points(map);
	projections = (t_projection *)malloc(sizeof(t_projection) * (map->size));
	if (!projections)
		print_error("Memory allocation failed for points data");
	i = 0;
	while (i < map->size)
	{
		projections[i].px = (pts[i].x - pts[i].y) * cos(window->angle_x);
		projections[i].py = (pts[i].x + pts[i].y) * sin(window->angle_y)
			- pts[i].z;
		projections[i].color = pts[i].color;
		i++;
	}
	free(pts);
	window->projections = projections;
}

t_point	*create_points(t_map *map)
{
	int		i;
	int		j;
	int		index;
	t_point	*points;
	int		**data;

	points = (t_point *)malloc(sizeof(t_point) * (map->size));
	if (!points)
		print_error("Memory allocation failed for points data");
	data = map->data;
	i = 0;
	index = 0;
	while (i < map->height)
	{
		j = 0;
		while (j < map->width)
		{
			points[index] = (t_point){j, i, data[i][j], get_color(data[i][j])};
			index++;
			j++;
		}
		i++;
	}
	return (points);
}

static int	get_color(int height)
{
	if (height < 0)
		return (0xFFFFFF);
	else if (height == 0)
		return (0xFFFFFF);
	else
		return (0x007BFF);
}
