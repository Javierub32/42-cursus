/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   start_simulation.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jurbanej <jurbanej@student.42malaga.c      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/07/20 11:03:05 by jurbanej          #+#    #+#             */
/*   Updated: 2025/07/20 11:03:07 by jurbanej         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/philosophers.h"

static int philo_dead(t_data *d)
{
	int		i;
	long	time_passed;

	pthread_mutex_lock(&d->dead_mutex);
	if (d->die)
	{
		pthread_mutex_unlock(&d->dead_mutex);
		return (d->die);
	}
	i = 0;
	while (i < d->num_philos)
	{
		time_passed = calc_time() - d->start_time;
		if (time_passed - d->philos[i].last_eat >= d->time_die)
		{
			d->die = 1;
			printf("[%ld]	[%d] \033[1;91mdied ☠️\033[0;39m\n", time_passed, d->philos[i].id);
			pthread_mutex_unlock(&d->dead_mutex);
			return (d->die);
		}
		i++;
	}
	pthread_mutex_unlock(&d->dead_mutex);
	return (d->die);
}

void *routine(void *arg)
{
	t_data *d;
	int		i;

	d = (t_data *)arg;
	pthread_mutex_lock(&d->i_mutex);
	i = d->currect_philo;
	d->currect_philo++;
	pthread_mutex_unlock(&d->i_mutex);
	if (i % 2 == 0)
		ft_usleep(d->time_eat / 2);
	while (philo_dead(d) == 0)
	{
		usleep(100);
	}
	return (NULL);
}
