/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   philosophers.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jurbanej <jurbanej@student.42malaga.c      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/07/20 11:03:05 by jurbanej          #+#    #+#             */
/*   Updated: 2025/07/20 11:03:07 by jurbanej         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/philosophers.h"

static void	print_data(t_data *d)
{
	printf("Number of philosophers: %d\n", d->num_philos);
	printf("Time to die: %d\n", d->time_die);
	printf("Time to eat: %d\n", d->time_eat);
	printf("Time to sleep: %d\n", d->time_sleep);
	printf("Must eat: %d\n", d->must_eat);
}

static void	print_philos(t_data *d)
{
	int	i;

	i = 0;
	while (i < d->num_philos)
	{
		printf("Philosopher %d: fork_l = %d, fork_r = %d\n",
			d->philos[i].id, d->philos[i].fork_l, d->philos[i].fork_r);
		i++;
	}
}

static void	print_start_simulation(void)
{
	printf("\n\nStarting simulation...\n\n");
}

int	main(int argc, char **argv)
{
	t_data	d;

	check_initial_errors(argc, argv);
	init_data(&d, argv);
	print_data(&d);
	print_philos(&d);
	print_start_simulation();
	// Hasta aquí corre la norma
	start_simulation(&d); // Por implementar

	while (!d.die)
	{
		usleep(1000); // 1ms
	}
	usleep(10000);
	//main_checker(&d);  // Por implementar
}
