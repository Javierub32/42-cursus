/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   start_simulation.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jurbanej <jurbanej@student.42malaga.c      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/07/20 11:03:05 by jurbanej          #+#    #+#             */
/*   Updated: 2025/07/20 11:03:07 by jurbanej         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/philosophers.h"

void	eat_and_sleep(t_data *d, int i)
{
	long time_now;

	if (philo_dead(d))
		return;

	time_now = calc_time() - d->start_time;
	d->philos[i].last_eat = time_now;
	d->philos[i].num_eat++;

	printf("\033[1;93m[%ld] [%d] is eating 🍝\033[0;39m\n", time_now, d->philos[i].id);
	ft_usleep(d->time_eat);

	if (philo_dead(d))
		return;

	time_now = calc_time() - d->start_time;
	printf("\033[1;94m[%ld] [%d] is sleeping 😴\033[0;39m\n", time_now, d->philos[i].id);
	ft_usleep(d->time_sleep);

	if (!philo_dead(d))
	{
		time_now = calc_time() - d->start_time;
		printf("\033[1;95m[%ld] [%d] is thinking 🤔\033[0;39m\n", time_now, d->philos[i].id);
	}
}


void	take_forks(t_data *d, int i)
{
	int	first_fork, second_fork;

	if (philo_dead(d))
		return;

	// Estrategia anti-deadlock: siempre tomar el fork con número menor primero
	if (d->philos[i].fork_l < d->philos[i].fork_r)
	{
		first_fork = d->philos[i].fork_l;
		second_fork = d->philos[i].fork_r;
	}
	else
	{
		first_fork = d->philos[i].fork_r;
		second_fork = d->philos[i].fork_l;
	}

	pthread_mutex_lock(&d->mutex[first_fork]);

	// Verificar si murió mientras esperaba el primer fork
	if (philo_dead(d))
	{
		pthread_mutex_unlock(&d->mutex[first_fork]);
		return;
	}

	printf("\033[1;92m[%ld] [%d] has taken a fork 🍴\033[0;39m\n",
		calc_time() - d->start_time, d->philos[i].id);

	if (d->num_philos == 1)
	{
		ft_usleep(d->time_die + 1);
		pthread_mutex_unlock(&d->mutex[first_fork]);
		return;
	}

	pthread_mutex_lock(&d->mutex[second_fork]);

	// Verificar si murió mientras esperaba el segundo fork
	if (philo_dead(d))
	{
		pthread_mutex_unlock(&d->mutex[second_fork]);
		pthread_mutex_unlock(&d->mutex[first_fork]);
		return;
	}

	printf("\033[1;92m[%ld] [%d] has taken a fork 🍴\033[0;39m\n",
		calc_time() - d->start_time, d->philos[i].id);

	// Aquí el filósofo come
	eat_and_sleep(d, i);

	// Liberar los forks en orden inverso
	pthread_mutex_unlock(&d->mutex[second_fork]);
	pthread_mutex_unlock(&d->mutex[first_fork]);
}
