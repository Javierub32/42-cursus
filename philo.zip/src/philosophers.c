/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   philosophers.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jurbanej <jurbanej@student.42malaga.c      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/07/20 11:03:05 by jurbanej          #+#    #+#             */
/*   Updated: 2025/07/20 11:03:07 by jurbanej         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/philosophers.h"

int	main(int argc, char **argv)
{
	t_data	d;
	int		i;

	check_initial_errors(argc, argv);
	init_data(&d, argv);
	start_simulation(&d);
	while (philo_dead(&d) == 0)
		ft_usleep(10);
	i = 0;
	while (i < d.num_philos)
		pthread_join(d.thread[i++], NULL);
	clean_data(&d);
	return (0);
}
