/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   error_handling.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jurbanej <jurbanej@student.42malaga.c      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/07/20 11:03:05 by jurbanej          #+#    #+#             */
/*   Updated: 2025/07/20 11:03:07 by jurbanej         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/philosophers.h"

// Si cabe, metes check_arguments en check_initial_errors

static void check_arguments(char **argv)
{
	int		i;
	long	num;

	i = 1;
	while (argv[i])
	{
		num = ft_atol(argv[i]);
		if (i == 1 && (num < 1 || num > 200))
			print_error(ERR_INVALID_ARG);
		else if (i > 1 && (num < 60 || num > 2147483647))
			print_error(ERR_INVALID_ARG);
		i++;
	}
}

void	check_initial_errors(int argc, char **argv)
{
	(void) argv;
	if (argc < 5 || argc > 6)
		print_error(ERR_INVALID_ARG);
	check_arguments(argv);
}
