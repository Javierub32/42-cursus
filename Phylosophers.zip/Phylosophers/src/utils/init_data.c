/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atol.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jurbanej <jurbanej@student.42malaga.c      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/07/20 11:03:05 by jurbanej          #+#    #+#             */
/*   Updated: 2025/07/20 11:03:07 by jurbanej         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/philosophers.h"

static t_philo *create_philos(int num_philos);

void	init_data(t_data *d, char **argv)
{
	d->num_philos = ft_atol(argv[1]);
	d->time_die = ft_atol(argv[2]);
	d->time_eat = ft_atol(argv[3]);
	d->time_sleep = ft_atol(argv[4]);
	if (argv[5])
		d->must_eat = ft_atol(argv[5]);
	else
		d->must_eat = -1;
	d->die = 0;
	d->start_time = calc_time();
	d->philos = create_philos(d->num_philos);
	d->threads = create_threads(d->num_philos);
}

static t_philo *create_philos(int num_philos)
{
	int		i;
	t_philo	*philos;

	philos = malloc(sizeof(t_philo) * num_philos);
	if (!philos)
		print_error(ERR_MALLOC);
	i = 0;
	while (i < num_philos)
	{
		philos[i].id = i + 1;
		philos[i].last_eat = 0;
		philos[i].fork_l = i;
		philos[i].fork_r = (i + 1) % num_philos;
		i++;
	}
	return (philos);
}